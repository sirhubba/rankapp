package se.gu.projekt.theciv5rankapp;

import java.lang.reflect.Array;
import java.text.DateFormat;
import java.util.ArrayList;

import se.gu.projekt.theciv5rankapp.classes.Game;
import se.gu.projekt.theciv5rankapp.classes.InGamePlayer;
import se.gu.projekt.theciv5rankapp.classes.Player;

import static se.gu.projekt.theciv5rankapp.classes.Game.victoryType.*;

public class GameCreator {

    /*private ArrayList<InGamePlayer> testGame;
    private ArrayList<Game> gameList;
    private ArrayList<Player> playerList;

    public void testGamePlayers(){
        testGame.add(new InGamePlayer("Harald", 1, 1, "SteamID1", "Aztec", 1));
        testGame.add(new InGamePlayer("Halvard", 2, 2, "SteamID2", "Sweden", 2));
        testGame.add(new InGamePlayer("Horace", 3, 3, "SteamID3", "France", 3));
        testGame.add(new InGamePlayer("Hans", 4, 4, "SteamID4", "Egypt", 4));
        testGame.add(new InGamePlayer("Hugo", 5, 5, "SteamID5", "Babylon", 5));
        testGame.add(new InGamePlayer("Harry", 6, 6, "SteamID6", "Denmark", 6));
    }

    public void createTestGames(){

        testGamePlayers();
        gameList.add(new Game(testGame,"2019-01-01", SCIENCE));
        gameList.add(new Game(testGame,"2019-01-02", DIPLOMACY));
        gameList.add(new Game(testGame,"2019-01-03", TOURISM));
        gameList.add(new Game(testGame,"2019-01-04", DOMINATION));

    }*/
}
