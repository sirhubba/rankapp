!#/bin/bash

java -jar winstone.jar --webroot webroot
